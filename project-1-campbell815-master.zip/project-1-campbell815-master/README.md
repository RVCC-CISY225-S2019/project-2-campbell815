## Project 1 About Me Starter Code 

### Instructions:

1. The file index.html is an HTML file, which is a document that will be displayed as a website. Open it in a browser like Google Chrome to see how it looks!
2. The file styles.css gives the page its look. What do you think happens if you temporarily remove that file and refresh the browser?
3. Open index.html up in a text editor like VS Code to edit it.
4. Add your name where it says [Lyan Kent]. Save the file. Refresh to see it in the browser.
5. Change the other questions in the HTML to your answers and saving the text in the file. Watch what happens when you refresh the page!
6. Get a picture of you and swap it out. The best picture will be one that is square. How are you going to do that? You can use Adobe Photoshop (which you will see done in class). Or you can use a free online photo editor like Fotor (https://www.fotor.com/app.html#/editor).

### Resources

* This Project is a modified clone of [Udacity Project 0 for Project Nautilus](https://github.com/udacity/project-nautilus-project-0)!

* Image by [Dee Thompson](https://www.pexels.com/photo/woman-posing-for-photo-while-smiling-1171015/)
* Logo from 
[PTRA](https://pixabay.com/en/logo-origami-bird-flying-blue-1913689/)
